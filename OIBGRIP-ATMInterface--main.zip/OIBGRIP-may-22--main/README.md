# OIBGRIP-may-22-
I performed task-3 of java internship
